
print(os.listdir())